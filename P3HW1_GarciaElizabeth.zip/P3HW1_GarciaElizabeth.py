#P3HW1
#Elizabeth Garcia
#CTI 110
#11/2/2023

grades =[]
mod_1 = float(input('Enter grade for Module 1: '))
grades.append(mod_1 )
mod_2 = float(input('Enter grade for Moduel 2: '))
grades.append(mod_2 )
mod_3 = float(input('Enter grade for Moduel 3: '))
grades.append(mod_3 )
mod_4 = float(input('Enter grade for Moduel 4: '))
grades.append(mod_4 )
mod_5 = float(input('Enter grade for Moduel 5: '))
grades.append(mod_5 )
mod_6 = float(input('Enter grade for Module 6: '))
grades.append(mod_6 )



highest = max(grades)
lowest = min(grades)
sum2 = sum(grades)
avg = sum2/len(grades)

print('-----------Results----------')
print('Lowest Grade: '       ,lowest)
print('Highest Grade: ',highest)
print('Sum of Grades: ',sum2 )
print(f'Average:        {avg:.2f}')
print('---------------------------')

if avg >=90:
   print('Your grade is: A')
else:
   if avg >=80:
      print('Your grade is: B')
   else:
      if avg >=70:
         print('Your grade is: C')
      else:
         if avg >=60:
            print('Your grade is: D')
         else:
            if avg < 60:
               print('Your grade is: F')
