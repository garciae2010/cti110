user_num = int(input('Enter integer:\n'))

print('You entered:',user_num)

print('4 squared is',user_num*user_num)

print('And 4 cubed is 64 !!')

user_num2 = int(input('Enter another integer:\n'))

print('4 + 5 is',user_num + user_num2)

print('4 * 5 is',user_num * user_num2)