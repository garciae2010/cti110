num1 = float(input())
num2 = float(input())
num3 = float(input())
num4 = float(input())

product = int(num1*num2*num3*num4+1)
avg = int(num1+num2+num3+num4)/4
product2 = (num1*num2*num3*num4)
avg2 = (num1+num2+num3+num4)/4
print(f'{product:.0f} {avg:.0f}')
print(f'{product2:.3f} {avg2:.3f}')

