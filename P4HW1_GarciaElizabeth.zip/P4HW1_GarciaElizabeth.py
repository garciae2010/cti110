#CTI-110
#P4HW1-Score List
#Elizabeth Garcia
#11/19/2023



how_many = int(input('How many scores do you want to enter? '))
print()

score = []

for x in range(1, how_many +1):
   score1 = float(input("Enter score #" + str(x) + ":  "))
   score.append(score1)
   
while x <0:
    print('INVALID Score entered!!!'
         'Score should be between 0 and 10')
         


avg = sum(score)/len(score)
lowest = min(score)

print('--------------Results----------')
print('Lowest score:',  min(score))
score.remove(min(score))

print('Modififed List:', score)
print(f'Average:       {avg:.2f}')



if avg >=90:
   print('Your grade is: A')
else:
   if avg >=80:
      print('Your grade is: B')
   else:
      if avg >=70:
         print('Your grade is: C')
      else:
         if avg >=60:
            print('Your grade is: D')
         else:
            if avg < 60:
               print('Your grade is: F')
